INSERT INTO book (book_id,book_name, book_description,book_count) VALUES
  (1,'The Secret', 'Motivational Book',4),
  (2,'Harry Potter', 'Fantasy',3);